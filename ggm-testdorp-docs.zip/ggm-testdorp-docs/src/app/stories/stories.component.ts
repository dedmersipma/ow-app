import {Component, Input} from '@angular/core';

@Component({
  selector: 'app-stories',
  templateUrl: './stories.component.html',
  styleUrls: ['./stories.component.scss']
})
export class StoriesComponent {

  @Input()
  activeProfile?: string

  get active() {
    return this.activeProfile === "lena-zijlstra" ? this.profiles[0] : this.profiles[1]
  }

  get activePersoon() {
    return this.activeProfile === "lena-zijlstra" ? this.lena.persoon : this.maddie.persoon
  }

  profiles = [
    {
      naam: "Lena Zijlstra",
      image: "/assets/lena_zijlstra.png",
      woonplaats: "Groningen",
      opleiding: "Rijksuniversiteit Groningen",
      email: "lena@gmail.com",
      telefoonnummer: "+31 676543210",
      implemented: true
    },
    {
      naam: "Maddie Peirs",
      image: "/assets/maddie_peirs.png",
      woonplaats: "Amsterdam",
      opleiding: "NHL",
      email: "maddie@gmail.com",
      telefoonnummer: "+31 676125718",
      implemented: true
    }, {
      naam: "Roy Matters",
      image: "/assets/roy_matters.png",
      woonplaats: "Breda",
      opleiding: "ROC Amsterdam",
      email: "roy@example.com",
      telefoonnummer: "+31 6 1234 5678",
      implemented: false
    },
    {
      naam: "Nick de Vries",
      image: "/assets/nick_de_vries.png",
      woonplaats: "Zwolle",
      opleiding: "NHL",
      email: "nick@example.com",
      telefoonnummer: "+31 6 9876 5432",
      implemented: false
    },
    {
      naam: "Emma Lopez",
      image: "/assets/emma_lopez.png",
      woonplaats: "Meppel",
      opleiding: "Rijksuniversiteit Groningen",
      email: "emma@example.com",
      telefoonnummer: "+31 6 6543 2109",
      implemented: false
    }

  ]

  lena = {
    "persoon": {
      "id": "5930801",
      "bsn": "237497360",
      "voornamen": "Lena",
      "geslachtsnaam": "Zijlstra",
      "weergaveNaam": "L. Zijlstra",
      "geboortedatum": "2003-11-11",
      "onderwijsdeelnamesHogerOnderwijs": [{
        "id": "23849954",
        "datumInschrijving": "2023-09-01",
        "datumUitschrijving": "2024-08-31",
        "inschrijvingvolgnummer": "64559519",
        "instelling": {
          "id": "db85da47-ac24-491e-a178-66b45282ed1d",
          "instellingscode": "21PC",
          "naamKort": "Rijksuniversiteit Groningen",
          "naamLang": "Rijksuniversiteit Groningen"
        },
        "opleiding": {
          "opleidingscode": "56860",
          "naamKort": "B Biologie",
          "naamLang": "B Biologie"
        }
      }],
      "onderwijsdeelnamesVo": [{
        "datumInschrijving": "2016-08-01",
        "datumUitschrijving": "2022-06-09",
        "inschrijvingvolgnummer": "2457602",
        "instelling": {
          "id": "8a172b86-653a-4b58-b3df-4a0bbcddee2f",
          "instellingscode": "20BV",
          "naamKort": "Praedinius Gymnasium",
          "naamLang": "Praedinius Gymnasium"
        }
      }]
    }
  };

  maddie = {
    "persoon": {
      "id": "7261082", // You can generate a unique id as needed
      "bsn": "938472615",
      "voornamen": "Maddie",
      "geslachtsnaam": "Peirs",
      "weergaveNaam": "M. Peirs",
      "geboortedatum": "1987-04-25",
      "onderwijsdeelnamesHogerOnderwijs": [
        {
          "id": "56783245",
          "datumInschrijving": "2010-09-01",
          "datumUitschrijving": "2014-08-31",
          "inschrijvingvolgnummer": "78451236",
          "instelling": {
            "id": "bc6a9d3f-8b28-412c-a1e3-61e2c1234c1a",
            "instellingscode": "21UC",
            "naamKort": "NHL",
            "naamLang": "NHL"
          },
          "opleiding": {
            "opleidingscode": "45678",
            "naamKort": "B Business Administration",
            "naamLang": "Bachelor in Business Administration"
          }
        }
      ],
      "onderwijsdeelnamesVo": [
        {
          "datumInschrijving": "1999-08-01",
          "datumUitschrijving": "2005-06-09",
          "inschrijvingvolgnummer": "1234567",
          "instelling": {
            "id": "8a172b86-653a-4b58-b3df-4a0bbcddee2f",
            "instellingscode": "20BV",
            "naamKort": "Stedelijk Gymnasium Lwd",
            "naamLang": "Stedelijk Gymnasium Leeuwarden"
          }
        }
      ]
    }
  };
}

