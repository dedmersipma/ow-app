import {NgModule} from '@angular/core';
import {StoriesComponent} from './stories.component';
import {ProfileCardComponent} from './profile-card/profile-card.component';
import {ProfileComponent} from './profile/profile.component';
import {CommonModule} from "@angular/common";


@NgModule({
  declarations: [
    StoriesComponent,
    ProfileCardComponent,
    ProfileComponent
  ],
  imports: [CommonModule],
  exports: [StoriesComponent, ProfileCardComponent]
})
export class StoriesModule {
}
