import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {StoriesComponent} from "./stories/stories.component";
import {RegistersComponent} from "./registers/registers.component";
import {HomeComponent} from "./home/home.component";
import {GettingStartedComponent} from "./getting-started/getting-started.component";

const routes: Routes = [
  {path: '', component: HomeComponent},
  {path: 'stories', component: StoriesComponent},
  {path: 'getting-started', component: GettingStartedComponent},
  {path: 'stories/:activeProfile', component: StoriesComponent},
  {path: 'registers', component: RegistersComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {bindToComponentInputs: true})],
  exports: [RouterModule],
})
export class AppRoutingModule {
}
