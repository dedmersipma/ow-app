import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RioComponent } from './rio/rio.component';
import { RegistersComponent } from './registers.component';



@NgModule({
  declarations: [
    RioComponent,
    RegistersComponent
  ],
  imports: [
    CommonModule
  ]
})
export class RegistersModule { }
