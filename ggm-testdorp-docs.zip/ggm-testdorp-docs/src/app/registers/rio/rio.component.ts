import {Component} from '@angular/core';

@Component({
  selector: 'app-rio',
  templateUrl: './rio.component.html',
  styleUrls: ['./rio.component.scss']
})
export class RioComponent {
  instelling = {
    "id": "db85da47-ac24-491e-a178-66b45282ed1d",
    "begindatum": "1914-08-23",
    "einddatum": null,
    "instellingserkenningPeriodes": [{
      "naamKort": "Rijksuniversiteit Groningen",
      "naamLang": "Rijksuniversiteit Groningen",
      "begindatum": "1999-09-13"
    }]
  }
}
