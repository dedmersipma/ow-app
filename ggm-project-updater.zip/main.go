package main

import (
	"bytes"
	"fmt"
	"go.uber.org/config"
	"gopkg.in/yaml.v3"
	"io"
	"log"
	"os"
	"path/filepath"
	"regexp"
	"strings"
)

type yml struct {
	yaml mp
	path string
}
type mp map[string]interface{}

type Repo struct {
	basePath string
}

var data = `
spring:
  datasource:
    hikari:
      data-source-properties:
        '[concurrent access resolution]': 1
`

var ggmDefaults = `
ggm:
  restdocs:
    enabled: false
  db:
    secure: true  
`

func main() {

	checkOutRepos()

	for _, repo := range getDirs() {
		fmt.Println(repo.basePath)
		if isAs400App(repo) {
			fmt.Printf("Updating deps for %s\n", repo.basePath)

			updateApplicationYml(repo)
			updateSecureConnectionAndRestdocs(repo)
			updatePom(repo)
			addJenkinsRelease(repo)
		}
	}
}

func getDirs() []Repo {
	dirPath := "./test-projects"
	var repos []Repo
	// Open the directory
	dir, err := os.Open(dirPath)
	if err != nil {
		log.Fatal("error opening dir")
	}
	defer func(dir *os.File) {
		err := dir.Close()
		if err != nil {

		}
	}(dir)

	// Read the directory entries
	entries, err := dir.Readdir(0)
	if err != nil {
		log.Fatal("error reading dir")
	}

	// Loop over the entries
	for _, entry := range entries {
		if entry.IsDir() {
			fmt.Println("Folder name:", entry.Name())
			repos = append(repos, Repo{basePath: dirPath + "/" + entry.Name()})
		}
	}
	return repos
}

func isAs400App(repo Repo) bool {
	cmPath := repo.basePath + "/helm/templates/_configmap.yaml"
	file, err := os.ReadFile(cmPath)
	if err != nil {
		return false
	}
	return strings.Contains(string(file), "secure")
}

// jenkins release file
func addJenkinsRelease(repo Repo) {
	templatePath := "./templates/Jenkinsfile.release"
	targetDir := repo.basePath + "/jenkins/"
	// Construct the target file path
	targetFilePath := filepath.Join(targetDir, filepath.Base(templatePath))

	// Check if the target file already exists
	if _, err := os.Stat(targetFilePath); os.IsNotExist(err) {
		// Target file does not exist, copy the template file to the target directory
		if err := copyFile(templatePath, targetFilePath); err != nil {
			fmt.Println("Error copying file:", err)
			return
		}
	}

	fmt.Println("File check and copy complete.")
}

func copyFile(sourcePath, targetPath string) error {
	sourceFile, err := os.Open(sourcePath)
	if err != nil {
		return err
	}
	defer func(sourceFile *os.File) {
		err := sourceFile.Close()
		if err != nil {

		}
	}(sourceFile)

	targetFile, err := os.Create(targetPath)
	if err != nil {
		return err
	}
	defer func(targetFile *os.File) {
		err := targetFile.Close()
		if err != nil {

		}
	}(targetFile)

	_, err = io.Copy(targetFile, sourceFile)
	if err != nil {
		return err
	}

	return nil
}

// update pom
func updatePom(repo Repo) {
	pom := repo.basePath + "/pom.xml"
	commonsVersion := getCommonsVersion(pom)
	if commonsVersion != "" {
		replaceInFile(pom, commonsVersion, "<ggm.commons.version>6.1.0</ggm.commons.version>")
	}
	parentVersion := getParentVersion(pom)
	if parentVersion != "" {
		replaceInFile(pom, parentVersion, "6.1.1")
	}
	replaceInFile(pom, "<classifier>jdk9</classifier>", "<classifier>java11</classifier>")

}

// update secure connection

func updateSecureConnectionAndRestdocs(repo Repo) {
	cmPath := repo.basePath + "/helm/templates/_configmap.yaml"
	// update _configmap.yaml
	replaceInFile(cmPath, "secure=true", "{{ ggm.db.secure }}")
	replaceInFile(cmPath, "{{ ggm.spring.restdocs.enabled }}", "{{ ggm.restdocs.enabled }}")
	// update default values.yaml
	c := mergeYamls(repo.basePath+"/helm/values.yaml", ggmDefaults)
	c.saveYml()
}

func replaceInFile(path string, from string, to string) {
	input, err := os.ReadFile(path)
	if err != nil {
		fmt.Println(err)
	}

	output := bytes.Replace(input, []byte(from), []byte(to), -1)

	if err = os.WriteFile(path, output, 0666); err != nil {
		fmt.Println(err)
	}
}

func getParentVersion(path string) string {
	input, err := os.ReadFile(path)
	if err != nil {
		fmt.Println(err)
	}
	pattern := regexp.MustCompile(`<artifactId>spring-boot-starter-parent<\/artifactId>\s*<version>([^<]+)</version>`)

	match := pattern.FindStringSubmatch(string(input))
	if match != nil {
		commons := match[1]
		fmt.Println("String to replace:", commons)
		return commons
	}
	return ""
}

func getCommonsVersion(path string) string {
	input, err := os.ReadFile(path)
	if err != nil {
		fmt.Println(err)
	}
	pattern := regexp.MustCompile(`<ggm\.commons\.version>(.*?)<\/ggm\.commons\.version>`)

	match := pattern.FindStringSubmatch(string(input))
	if match != nil {
		commons := match[0]
		fmt.Println("String to replace:", commons)
		return commons
	}
	return ""
}

// update application.yml
func updateApplicationYml(repo Repo) {
	ymlPath := repo.basePath + "/src/main/resources/application.yml"
	yamlPath := repo.basePath + "/src/main/resources/application.yaml"
	var filePath string
	if _, err := os.Stat(yamlPath); os.IsNotExist(err) {
		filePath = ymlPath
	} else {
		filePath = yamlPath
	}
	c := mergeYamls(filePath, data)
	c.saveYml()
}

func mergeYamls(basePath string, template string) yml {
	y := make(mp)
	b := yml{
		yaml: y,
		path: basePath,
	}

	err := yaml.Unmarshal([]byte(data), &b.yaml)
	if err != nil {
		log.Fatal("Failed to unmarshal src YAML:", err)
	}
	base := readYaml(basePath)
	override := strings.NewReader(template)
	provider, err := config.NewYAML(config.Source(base), config.Source(override))
	if err != nil {
		panic(err)
	}

	var c mp
	if err := provider.Get(config.Root).Populate(&c); err != nil {
		panic(err)
	}
	b.yaml = c
	return b
}

func (y yml) saveYml() {
	var b bytes.Buffer
	yamlEncoder := yaml.NewEncoder(&b)
	yamlEncoder.SetIndent(2)
	err := yamlEncoder.Encode(&y.yaml)
	if err != nil {
		return
	}
	if err != nil {
		fmt.Printf("Error while Marshaling. %v", err)
	}
	err = os.WriteFile(y.path, b.Bytes(), 0644)
	if err != nil {
		panic("Unable to write data into the file")
	}
}
func readYaml(p string) io.Reader {
	bs, err := os.ReadFile(p)
	if err != nil {
		log.Fatal(err)
	}

	return strings.NewReader(string(bs))
}
