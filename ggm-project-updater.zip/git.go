package main

import (
	"fmt"
	"os/exec"
	"sync"
)

func checkOutRepos() {
	repoURLs := []string{
		"git@github.com:dedmersipma/test-project1.git",
		"git@github.com:dedmersipma/test-project2.git",
	}

	var wg sync.WaitGroup
	// Loop over the repository URLs
	for _, repoURL := range repoURLs {
		wg.Add(1)
		go checkOutRepo(repoURL, &wg)
	}

	wg.Wait()
	fmt.Println("All projects cloned.")
}
func checkOutRepo(repoURL string, wg *sync.WaitGroup) {
	defer wg.Done()
	branch := "main"
	newBranch := "feature/deps-update"

	// Clone the repository
	cmd := exec.Command("git", "clone", repoURL)

	err := cmd.Run()
	if err != nil {
		fmt.Println("Error cloning repository:", err)
		return
	}

	// Get the repository directory
	repoDir := getRepoDir(repoURL)

	// Checkout the develop branch
	cmd = exec.Command("git", "checkout", branch)
	cmd.Dir = repoDir

	err = cmd.Run()
	if err != nil {
		fmt.Println("Error checking out branch:", err)
		return
	}

	// Create and checkout the new branch
	cmd = exec.Command("git", "checkout", "-b", newBranch)
	cmd.Dir = repoDir

	err = cmd.Run()
	if err != nil {
		fmt.Println("Error creating new branch:", err)
		return
	}

	//pushBranch(cmd, newBranch, repoDir)

	fmt.Println("Repository", repoURL, "processed successfully.")

}

func pushBranch(cmd *exec.Cmd, newBranch string, repoDir string) {
	// Push the new branch
	cmd = exec.Command("git", "push", "-u", "origin", newBranch)
	cmd.Dir = repoDir

	err := cmd.Run()
	if err != nil {
		fmt.Println("Error pushing new branch:", err)
		return
	}
}

// Helper function to get the repository directory based on the base directory and repository URL
func getRepoDir(repoURL string) string {
	repoName := getRepoName(repoURL)
	return fmt.Sprintf("%s", repoName)
}

// Helper function to get the repository name from the repository URL
func getRepoName(repoURL string) string {
	// Example: https://github.com/example/repo.git
	// Extracts: repo
	repoURL = repoURL[:len(repoURL)-4] // Remove ".git" suffix
	lastSlash := len(repoURL) - 1
	for i := len(repoURL) - 1; i >= 0; i-- {
		if repoURL[i] == '/' {
			lastSlash = i
			break
		}
	}
	return repoURL[lastSlash+1:]
}
