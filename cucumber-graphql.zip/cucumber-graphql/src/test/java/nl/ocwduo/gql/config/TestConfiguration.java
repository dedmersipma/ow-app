package nl.ocwduo.gql.config;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan
public class TestConfiguration {
}
