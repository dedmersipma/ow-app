package nl.ocwduo.gql.steps;

import io.cucumber.spring.CucumberContextConfiguration;
import nl.ocwduo.gql.config.TestConfiguration;
import org.springframework.test.context.ContextConfiguration;

@CucumberContextConfiguration
@ContextConfiguration(classes = TestConfiguration.class)
public class CucumberSpringConfig {
}
