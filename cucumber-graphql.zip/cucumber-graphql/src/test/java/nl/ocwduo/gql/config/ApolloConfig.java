package nl.ocwduo.gql.config;

import com.apollographql.apollo3.ApolloClient;
import com.apollographql.apollo3.api.http.HttpMethod;
import com.apollographql.apollo3.network.http.LoggingInterceptor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@Slf4j
public class ApolloConfig {
    @Bean
    public ApolloClient client() {
        return new ApolloClient.Builder()
                .httpServerUrl("http://localhost:4000")
                .autoPersistedQueries(HttpMethod.Post)
                .addHttpInterceptor(new LoggingInterceptor())
                .build();
    }
}
