package nl.ocwduo.gql.steps;

import io.cucumber.java.nl.Gegeven;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
public class TestdorpSteps {

    @Gegeven("Een registratie van Rijksuniversiteit Groningen in RIO")
    public void rijksuniversiteitGroningen() {
        log.info("Setting up Rijksuniversiteit Groningen");
    }

    @Gegeven("Een registratie van de opleiding Archeologie in RIO")
    public void archelogie() {
        log.info("Setting up opleiding Archeologie - Rijksuniversiteit Groningen");
    }

    @Gegeven("Een registratie van de opleiding IT in RIO")
    public void itOpleiding() {
        log.info("Setting up opleiding IT - Rijksuniversiteit Groningen");
    }

    @Gegeven("Volledige registratie van Rijksuniversiteit Groningen in RIO")
    public void rijksuniversiteitGroningenVolledig() {
        rijksuniversiteitGroningen();
        archelogie();
        itOpleiding();
    }
}
