package nl.ocwduo.gql.steps;

import com.apollographql.apollo3.ApolloClient;
import com.apollographql.apollo3.rx3.Rx3Apollo;
import io.cucumber.java.nl.Dan;
import io.cucumber.java.nl.Wanneer;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nl.ocwduo.gqloperation.InstellingById_UC001Query;

@Slf4j
@RequiredArgsConstructor
public class RioApiSteps {
    private final ApolloClient client;

    @Wanneer("De Rijkuniversiteit wordt opgevraagd obv code")
    public void fetchObvVanCode() {
        var response = Rx3Apollo
                .single(client.query(InstellingById_UC001Query
                        .builder()
                        .id("200")
                        .build()))
                .blockingGet();
        assert response.data != null;
//        log.info("{}", response.data.dep);
        log.info("Executing query {}", InstellingById_UC001Query.OPERATION_NAME);
    }

    @Dan("Is de opvraging valide")
    public void isDeOpvragingValide() {
        log.info("Validation succesfull!");
    }
}
