# ggm-gql-verzoeken

## Functional Description

Provide an overview of the functions and purpose of the ggm-gql-verzoeken subgraph.

## Queries

Detail the queries specific to the ggm-gql-verzoeken subgraph.

## Federated Queries

Explain the federated queries associated with the ggm-gql-verzoeken subgraph and their contribution to the federated data graph.
    