# ggm-gql-persoon

## Description

The ggm-gql-persoon subgraph is responsible for managing information related to individuals. This section provides an in-depth look into its functions, queries, and data mapping.

## Queries

### persoon
### zoekPersoon

## Mapping

| JB_PSN        | Persoon                 |
|---------------|-------------------------|
| id            | id                      |
| first_name    | firstName               |
| last_name     | lastName                |
| tussenvoegsel | tussenvoegsel           |
| voorvoegsel   | voorvoegsel             |
| bba_indicatie | indicatieBba            |
|               | weergavenaam (function) |
| ...           | ...                     |


## Functions
### weergavenaam

The `weergavenaam` function combines various name components to create a display name.

```javascript
function weergavenaam(person) {
const { firstName, lastName, tussenvoegsel, voorvoegsel } = person;
// Logic to combine name components
// Example: return `${firstName} ${tussenvoegsel} ${lastName}`;
}
```
