# ggm-gql-grondslaggegevens

## Functional Description

Explain the role and functionality of the ggm-gql-grondslaggegevens subgraph.

## Queries

List and describe the queries that are unique to the ggm-gql-grondslaggegevens subgraph.

## Federated Queries

Explore the federated queries associated with the ggm-gql-grondslaggegevens subgraph and their integration into the federated data graph.
