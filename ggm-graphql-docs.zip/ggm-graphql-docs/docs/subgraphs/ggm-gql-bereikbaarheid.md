# ggm-gql-bereikbaarheid

## Functional Description

Describe the functionality and purpose of the ggm-gql-bereikbaarheid subgraph.

## Queries

Detail the queries that are specific to the ggm-gql-bereikbaarheid subgraph.

## Federated Queries

Examine the federated queries associated with the ggm-gql-bereikbaarheid subgraph and their contributions to the federated data graph.

## Email
```mermaid
graph TD
  Persoon.id --> Email.persoonsId
  Persoon.id --> Postadres.persoonsId
```

## Postadres
Hier komt de functionele docs van postadres

