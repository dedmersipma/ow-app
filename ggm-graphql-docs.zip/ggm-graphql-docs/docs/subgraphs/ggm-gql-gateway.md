# ggm-gql-gateway

## Functional Description

Describe the role and functionality of the ggm-gql-gateway subgraph within the Federated GraphQL solution.

## Queries

List and detail the queries that the ggm-gql-gateway subgraph supports.

## Federated Queries

Highlight the federation entry points associated with the ggm-gql-gateway subgraph and how it contributes to the overall federated data graph.
