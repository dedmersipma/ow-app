---
# https://vitepress.dev/reference/default-theme-home-page
layout: home

hero:
  name: "Project Phoenix"
  text: "rising from the ashes"
  tagline: A product by GGM


features:
  - title: Feature A
    details: Lorem ipsum dolor sit amet, consectetur adipiscing elit
  - title: Feature B
    details: Lorem ipsum dolor sit amet, consectetur adipiscing elit
  - title: Feature C
    details: Lorem ipsum dolor sit amet, consectetur adipiscing elit
---

