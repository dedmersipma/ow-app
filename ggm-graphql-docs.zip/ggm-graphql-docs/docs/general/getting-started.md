# Getting Started

Follow the steps in this guide to quickly set up and start using the Federated GraphQL solution. From installation to making your first queries, get up and running in no time.
