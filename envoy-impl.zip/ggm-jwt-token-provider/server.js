const express = require("express");
const fs = require("fs");
const jsonwebtoken = require("jsonwebtoken");
const bodyParser = require('body-parser')
const app = express();

// create application/json parser
const jsonParser = bodyParser.json()

const issuer = "https://ggm.nl";

const tokens = {
    wvb: {
        username: "wvb",
        roles: "get:verzoeken;get:basePersoon;get:grondslag",
        iss: issuer
    },
    eff: {
        username: "eff",
        roles: "get:verzoeken;get:basePersoon",
        iss: issuer
    }
}

app.post("/login", jsonParser,(req, res) => {
    console.log(req.body)
    const { username } = req.body;
    console.log(`${username} is trying to login ..`);

    if (username in tokens) {
        // sign with RSA SHA256
        const privateKey = fs.readFileSync('private.key');
        const token = jsonwebtoken.sign(tokens[username], privateKey, { algorithm: 'RS256' });
        return res.json({
            token: token,
        });
    }

    return res
        .status(401)
        .json({ message: "The username and password you provided are invalid" });
});

app.listen(3001, () => {
    console.log("API running on localhost:3001");
});