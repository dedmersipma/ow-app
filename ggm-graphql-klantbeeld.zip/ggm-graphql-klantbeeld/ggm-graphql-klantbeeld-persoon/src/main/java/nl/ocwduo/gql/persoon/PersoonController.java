package nl.ocwduo.gql.persoon;

import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Controller
public class PersoonController {

    private final Map<String, Persoon> PRODUCTS = Stream.of(
            new Persoon("1", "Saturn V", "The Original Super Heavy-Lift Rocket!"),
            new Persoon("2", "Lunar Module", "Popular"),
            new Persoon("3", "Space Shuttle", "Crashed"),
            new Persoon("4", "Falcon 9", "Reusable Medium-Lift Rocket"),
            new Persoon("5", "Dragon", "Reusable Medium-Lift Rocket"),
            new Persoon("6", "Starship", "Super Heavy-Lift Reusable Launch Vehicle")
    ).collect(Collectors.toMap(Persoon::id, product -> product));

    @QueryMapping
    public Persoon persoon(@Argument String id) {
        return PRODUCTS.get(id);
    }
}
