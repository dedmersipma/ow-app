package nl.ocwduo.gql.persoon;

public record Persoon(String id,
                      String naam,
                      String achternaam) {

}
