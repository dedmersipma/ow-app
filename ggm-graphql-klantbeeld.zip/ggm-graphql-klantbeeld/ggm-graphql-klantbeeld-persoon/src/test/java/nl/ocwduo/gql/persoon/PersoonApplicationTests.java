package nl.ocwduo.gql.persoon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersoonApplicationTests {

    @Test
    void contextLoads() {
    }

}
