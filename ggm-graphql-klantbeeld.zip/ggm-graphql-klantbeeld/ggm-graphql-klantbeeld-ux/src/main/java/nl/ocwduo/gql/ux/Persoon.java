package nl.ocwduo.gql.ux;

public record Persoon(String id) {
    public static final String PERSOON_TYPE = "Persoon";
}
