package nl.ocwduo.gql.ux;

import com.apollographql.federation.graphqljava.Federation;
import com.apollographql.federation.graphqljava._Entity;
import com.apollographql.federation.graphqljava.tracing.FederatedTracingInstrumentation;
import graphql.execution.instrumentation.Instrumentation;
import graphql.schema.DataFetcher;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.graphql.GraphQlSourceBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.graphql.execution.ClassNameTypeResolver;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static nl.ocwduo.gql.ux.Persoon.PERSOON_TYPE;

@Configuration
public class GraphQLConfiguration {

    @Bean
    public GraphQlSourceBuilderCustomizer federationTransform() {
        DataFetcher<?> entityDataFetcher = env -> {
            List<Map<String, Object>> representations = env.getArgument(_Entity.argumentName);
            return representations.stream()
                    .map(representation -> {
                        if (PERSOON_TYPE.equals(representation.get("__typename"))) {
                            return new Persoon((String) representation.get("id"));
                        }
                        return null;
                    })
                    .collect(Collectors.toList());
        };

        return builder ->
                builder.schemaFactory((registry, wiring) ->
                        Federation.transform(registry, wiring)
                                .fetchEntities(entityDataFetcher)
                                .resolveEntityType(new ClassNameTypeResolver())
                                .build()
                );
    }

    @Bean
    @ConditionalOnProperty(prefix = "graphql.tracing", name = "enabled", matchIfMissing = true)
    public Instrumentation tracingInstrumentation() {
        return new FederatedTracingInstrumentation();
    }
}
