package nl.ocwduo.gql.ux;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UxApplication {

    public static void main(String[] args) {
        SpringApplication.run(UxApplication.class, args);
    }

}
