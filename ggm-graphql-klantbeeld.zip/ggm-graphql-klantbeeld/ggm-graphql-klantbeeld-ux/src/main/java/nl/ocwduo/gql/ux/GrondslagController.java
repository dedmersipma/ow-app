package nl.ocwduo.gql.ux;

import org.springframework.graphql.data.method.annotation.SchemaMapping;
import org.springframework.stereotype.Controller;

import java.util.Collections;
import java.util.List;
import java.util.Map;

@Controller
public class GrondslagController {

    private final Map<String, List<Grondslaggegeven>> GRONDSLAGGEGEVENS = Map.of(
            "2", List.of(new Grondslaggegeven("1020", "Very cramped :( Do not recommend."), new Grondslaggegeven("1021", "Got me to the Moon!")),
            "3", List.of(new Grondslaggegeven("1030", "Text")),
            "4", List.of(new Grondslaggegeven("1040", "Sterk"), new Grondslaggegeven("1041", "Reusable!"), new Grondslaggegeven("1042", "Bla")),
            "5", List.of(new Grondslaggegeven("1050", "Amazing! Would Fly Again!"), new Grondslaggegeven("1051", "Verhaal"))
    );

    @SchemaMapping
    public List<Grondslaggegeven> grondslaggegevens(Persoon persoon) {
        return GRONDSLAGGEGEVENS.getOrDefault(persoon.id(), Collections.emptyList());
    }
}
