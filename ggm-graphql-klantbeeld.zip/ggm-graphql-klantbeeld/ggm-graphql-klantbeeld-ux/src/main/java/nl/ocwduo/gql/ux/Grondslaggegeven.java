package nl.ocwduo.gql.ux;

public record Grondslaggegeven(String id, String text, String melding) {
    public Grondslaggegeven(String id, String text) {
        this(id, text, null);
    }
}
