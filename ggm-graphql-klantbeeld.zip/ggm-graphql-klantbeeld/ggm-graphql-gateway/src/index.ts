import {ApolloServer} from '@apollo/server';
import {startStandaloneServer} from '@apollo/server/standalone';
import {
    ApolloGateway,
    GraphQLDataSourceProcessOptions,
    IntrospectAndCompose,
    RemoteGraphQLDataSource
} from '@apollo/gateway';

class DebugDataSource extends RemoteGraphQLDataSource {
    willSendRequest({request}: GraphQLDataSourceProcessOptions<Record<string, any>>): void {
        console.log(`Operation name: ${request.operationName}`);
        console.log(`Query body: ${request.query}`);
        console.log(`Variables: ${JSON.stringify(request.variables)}`);
    }
}

// Initialize an ApolloGateway instance and introspect schemas (demo purposes only).
const gateway = new ApolloGateway({
    debug: false,
    buildService({url}) {
        return new DebugDataSource({url})
    },
    supergraphSdl: new IntrospectAndCompose({
        subgraphs: [
            {name: 'persoon', url: 'http://localhost:8080/graphql'},
            {name: 'ux', url: 'http://localhost:8081/graphql'}
        ]
    }),
});

// Pass the ApolloGateway to the ApolloServer constructor
const server = new ApolloServer({
    gateway,
});

// Note the top-level `await`!
const {url} = await startStandaloneServer(server);
console.log(`🚀  Server ready at ${url}`);